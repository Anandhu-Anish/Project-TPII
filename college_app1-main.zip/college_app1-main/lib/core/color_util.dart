import 'package:flutter/material.dart';

class ColorUtil {
  static const Color AdminCardColor = Color(0xffD9C7E7);
  static const Color TeacherCardColor = Color(0xffFF9A62);
  static const Color StudentCardColor = Color(0xff85C7EE);
}
